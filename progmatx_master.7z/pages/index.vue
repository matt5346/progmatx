<template>
  <div class="container">
    <div>
      <menu />
    </div>
  </div>
</template>

<script>
export default {}
</script>
