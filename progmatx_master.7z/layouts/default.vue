<template>
  <div class="app">
    <Menu />
    <Nuxt />
  </div>
</template>

<script>
import Menu from '@/components/menu/menu'

export default {
  name: 'App',
  components: {
    Menu
  }
}
</script>

<style lang="scss">
@import '../assets/mixins';
</style>
