<template>
  <div class="menu">
    <Logo />
    <nav class="menu__options">
      <ul class="menu__options-nav">
        <li>Music</li>
        <li>Samples</li>
        <li>Contacts</li>
      </ul>
      <div class="menu__options-socials">
        <Instagram />
      </div>
    </nav>
  </div>
</template>
<script>
import Logo from '@/static/logo.svg'
import Instagram from '@/static/socials/instagram.svg'

export default {
  name: 'Menu',
  components: {
    Instagram,
    Logo
  }
}

</script>

<style lang="scss">
@import "./styles";
</style>
